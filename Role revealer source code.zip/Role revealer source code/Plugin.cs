using BepInEx;
using BepInEx.Unity.IL2CPP;
using UnityEngine;
using System.Collections.Generic;

namespace Omnicient
{
    [BepInPlugin(
        "com.RoleRevealer",
        "Role revealer",
        "1.0.0"
    )]
    [BepInProcess("Among Us.exe")]
    public class Plugin : BasePlugin
    {
        public override void Load()
        {
            AddComponent<OmniscientBehaviour>();

            Log.LogInfo("Role Revealer by KRUSH loaded");
        }
    }

    public class OmniscientBehaviour : MonoBehaviour
    {
        private const float REVEAL_INTERVAL = 1.5f;

        private Rect windowRect =
            new Rect(20, 20, 320, 580);

        private bool showWindow = true;

        private Vector2 playerScrollPosition =
            Vector2.zero;

        private HashSet<byte> selectedPlayers =
            new HashSet<byte>();

        private Queue<PlayerControl> revealQueue =
            new Queue<PlayerControl>();

        private float revealTimer = 0f;

        private bool revealInProgress = false;

        private void Update()
        {
            if (!revealInProgress)
                return;

            revealTimer += Time.deltaTime;

            if (revealTimer < REVEAL_INTERVAL)
                return;

            revealTimer = 0f;

            if (revealQueue.Count == 0)
            {
                revealInProgress = false;
                return;
            }

            PlayerControl target =
                revealQueue.Dequeue();

            RevealRole(target);

            if (revealQueue.Count == 0)
            {
                revealInProgress = false;
            }
        }

        private void OnGUI()
        {
            Event currentEvent = Event.current;

            if (currentEvent.type == EventType.KeyDown &&
                currentEvent.keyCode == KeyCode.F8)
            {
                showWindow = !showWindow;

                currentEvent.Use();
            }

            if (!showWindow)
                return;

            windowRect = GUI.Window(
                24680,
                windowRect,
                (GUI.WindowFunction)DrawWindow,
                "[ Role revealer ]"
            );
        }

        private void DrawWindow(int windowID)
        {
            GUILayout.Space(8);

            GUILayout.Label("Select players:");

            GUILayout.Space(5);

            playerScrollPosition =
                GUILayout.BeginScrollView(
                    playerScrollPosition,
                    GUILayout.Height(300)
                );

            if (PlayerControl.AllPlayerControls != null)
            {
                for (
                    int i = 0;
                    i < PlayerControl.AllPlayerControls.Count;
                    i++
                )
                {
                    PlayerControl player =
                        PlayerControl.AllPlayerControls[i];

                    if (player == null)
                        continue;

                    if (player.Data == null)
                        continue;

                    byte playerId =
                        player.PlayerId;

                    string playerName =
                        player.Data.PlayerName;

                    string roleName =
                        player.Data.RoleType.ToString();

                    bool isSelected =
                        selectedPlayers.Contains(playerId);

                    string prefix =
                        isSelected ? "[X] " : "[ ] ";

                    string displayName =
                        prefix +
                        playerName +
                        " (" +
                        roleName +
                        ")";

                    if (GUILayout.Button(
                        displayName,
                        GUILayout.Height(30)
                    ))
                    {
                        TogglePlayer(playerId);
                    }
                }
            }

            GUILayout.EndScrollView();

            GUILayout.Space(8);

            if (GUILayout.Button(
                "Reveal Selected Players' Roles",
                GUILayout.Height(30)
            ))
            {
                QueueSelectedPlayers();
            }

            GUILayout.Space(4);

            if (GUILayout.Button(
                "Reveal All Impostors",
                GUILayout.Height(30)
            ))
            {
                QueueAllImpostors();
            }

            GUILayout.Space(4);

            if (GUILayout.Button(
                "Reveal All Roles",
                GUILayout.Height(30)
            ))
            {
                QueueAllPlayers();
            }

            GUILayout.Space(4);

            if (GUILayout.Button(
                "Reveal all roles (0s cooldown)",
                GUILayout.Height(30)
            ))
            {
                RevealAllRolesInstant();
            }

            GUILayout.Space(4);

            if (GUILayout.Button(
                "Clear Selection",
                GUILayout.Height(25)
            ))
            {
                selectedPlayers.Clear();
            }

            GUI.DragWindow(
                new Rect(
                    0,
                    0,
                    windowRect.width,
                    20
                )
            );
        }

        private void TogglePlayer(byte playerId)
        {
            if (selectedPlayers.Contains(playerId))
            {
                selectedPlayers.Remove(playerId);
            }
            else
            {
                selectedPlayers.Add(playerId);
            }
        }

        private void QueueSelectedPlayers()
        {
            ClearRevealQueue();

            if (PlayerControl.AllPlayerControls == null)
                return;

            for (
                int i = 0;
                i < PlayerControl.AllPlayerControls.Count;
                i++
            )
            {
                PlayerControl player =
                    PlayerControl.AllPlayerControls[i];

                if (player == null)
                    continue;

                if (player.Data == null)
                    continue;

                if (!selectedPlayers.Contains(player.PlayerId))
                    continue;

                revealQueue.Enqueue(player);
            }

            StartRevealQueue();
        }

        private void QueueAllImpostors()
        {
            ClearRevealQueue();

            if (PlayerControl.AllPlayerControls == null)
                return;

            for (
                int i = 0;
                i < PlayerControl.AllPlayerControls.Count;
                i++
            )
            {
                PlayerControl player =
                    PlayerControl.AllPlayerControls[i];

                if (player == null)
                    continue;

                if (player.Data == null)
                    continue;

                if (player.Data.Role == null)
                    continue;

                if (!player.Data.Role.IsImpostor)
                    continue;

                revealQueue.Enqueue(player);
            }

            StartRevealQueue();
        }

        private void QueueAllPlayers()
        {
            ClearRevealQueue();

            if (PlayerControl.AllPlayerControls == null)
                return;

            for (
                int i = 0;
                i < PlayerControl.AllPlayerControls.Count;
                i++
            )
            {
                PlayerControl player =
                    PlayerControl.AllPlayerControls[i];

                if (player == null)
                    continue;

                if (player.Data == null)
                    continue;

                revealQueue.Enqueue(player);
            }

            StartRevealQueue();
        }

        private void StartRevealQueue()
        {
            if (revealQueue.Count == 0)
                return;

            if (revealQueue.Count <= 6)
            {
                RevealQueueInstant();
                return;
            }

            revealTimer = REVEAL_INTERVAL;
            revealInProgress = true;
        }

        private void RevealQueueInstant()
        {
            while (revealQueue.Count > 0)
            {
                PlayerControl target =
                    revealQueue.Dequeue();

                RevealRole(target);
            }

            revealInProgress = false;
            revealTimer = 0f;
        }

        private void RevealAllRolesInstant()
        {
            ClearRevealQueue();

            if (PlayerControl.AllPlayerControls == null)
                return;

            for (
                int i = 0;
                i < PlayerControl.AllPlayerControls.Count;
                i++
            )
            {
                PlayerControl player =
                    PlayerControl.AllPlayerControls[i];

                if (player == null)
                    continue;

                if (player.Data == null)
                    continue;

                revealQueue.Enqueue(player);
            }

            RevealQueueInstant();
        }

        private void ClearRevealQueue()
        {
            revealQueue.Clear();
            revealInProgress = false;
            revealTimer = 0f;
        }

        private void RevealRole(PlayerControl target)
        {
            if (target == null)
                return;

            if (target.Data == null)
                return;

            PlayerControl local =
                PlayerControl.LocalPlayer;

            if (local == null)
                return;

            string roleName =
                target.Data.RoleType.ToString();

            int colorId =
                target.Data.DefaultOutfit.ColorId;

            string colorName =
                Palette.ColorNames[colorId]
                    .ToString()
                    .Replace("Color", "");

            string message =
                target.Data.PlayerName +
                "(" +
                colorName +
                ") is " +
                roleName;

            local.RpcSendChat(message);
        }
    }
}